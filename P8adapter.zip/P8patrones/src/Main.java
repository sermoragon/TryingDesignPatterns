public class Main {

    public static void main(String[] args) {
        probarMiArray(new AdaptadorLista());
        probarMiArray(new MiArrayClase());
    }

    private static void probarMiArray(MiArray miArray) {
        System.out.println("Probando " + miArray.getClass().getSimpleName() + ":");

        miArray.aniadir(10);
        miArray.aniadir(20);
        miArray.aniadir(30);

        System.out.println("Tamaño: " + miArray.tamanio());
        System.out.println("Primero: " + miArray.primero());
        System.out.println("Último: " + miArray.ultimo());

        miArray.eliminar(1);

        System.out.println("Después de eliminar el segundo elemento:");
        System.out.println("Tamaño: " + miArray.tamanio());
        System.out.println("Primero: " + miArray.primero());
        System.out.println("Último: " + miArray.ultimo());
        System.out.println();
    }
}
