import java.util.ArrayList;
import java.util.List;

public class AdaptadorLista implements MiArray {
    private List<Integer> lista;

    public AdaptadorLista() {
        lista = new ArrayList<>();
    }

    @Override
    public void aniadir(int valor) {
        lista.add(valor);
    }

    @Override
    public void eliminar(int posicion) {
        lista.remove(posicion);
    }

    @Override
    public void vaciar() {
        lista.clear();
    }

    @Override
    public boolean esVacio() {
        return lista.isEmpty();
    }

    @Override
    public int tamanio() {
        return lista.size();
    }

    @Override
    public int primero() {
        if (!lista.isEmpty()) {
            return lista.get(0);
        } else {
            throw new IllegalStateException("La lista está vacía");
        }
    }

    @Override
    public int ultimo() {
        if (!lista.isEmpty()) {
            return lista.get(lista.size() - 1);
        } else {
            throw new IllegalStateException("La lista está vacía");
        }
    }

    @Override
    public int devolverPosicion(int posicion) {
        return lista.get(posicion);
    }
}
