package org.app;

public interface Observador {
    String toString();
    void update();
    public String getName();
}
