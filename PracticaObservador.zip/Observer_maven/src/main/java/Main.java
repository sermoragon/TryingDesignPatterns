import GUI.UsuarioGUI;
import org.app.*;

public class Main {
    public static void main(String[] args) {
        // Contexto 1
        /*Sujeto sujetoHacking = new SujetoConcreto();
        sujetoHacking.agregarObservador(new ObservadorNewsApi(sujetoHacking, "Sergio"));

        // Contexto 2
        Sujeto sujetoPatrones = new SujetoConcreto("patrones de diseño");
        sujetoPatrones.agregarObservador(new ObservadorNewsApi(sujetoPatrones, "Samuel"));

        sujetoPatrones.run();
        sujetoHacking.run();*/
        UsuarioGUI gui1 = new UsuarioGUI();


    }
}
