

public class ChatAppGUI {
    public static void main(String[] args) {
        ChatMediator chatMediator = new ChatMediatorImpl();

        User user1 = new User("User1", chatMediator);
        User user2 = new User("User2", chatMediator);
        User user3 = new User("User3", chatMediator);
        User user4 = new User("User4", chatMediator);
        User user5 = new User("User5", chatMediator);

        ((ChatMediatorImpl) chatMediator).addUserToConversation("Chat1", user1);
        ((ChatMediatorImpl) chatMediator).addUserToConversation("Chat1", user2);

        ((ChatMediatorImpl) chatMediator).addUserToConversation("Chat2", user1);
        ((ChatMediatorImpl) chatMediator).addUserToConversation("Chat2", user3);

        ((ChatMediatorImpl) chatMediator).addUserToConversation("Chat3", user1);
        ((ChatMediatorImpl) chatMediator).addUserToConversation("Chat3", user4);
        ((ChatMediatorImpl) chatMediator).addUserToConversation("Chat3", user5);

    }
}
