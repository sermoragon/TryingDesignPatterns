import java.util.List;
import java.util.Map;

public interface ChatMediator {
    void sendMessage(String message, User sender, String conversationId);
    Map<String, List<User>> getConversations();
}
