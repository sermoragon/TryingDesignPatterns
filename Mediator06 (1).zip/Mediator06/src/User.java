import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class User {
    private String name;
    private ChatMediator mediator;
    private List<String> joinedConversations;
    private JTextArea chatArea;
    private JComboBox<String> chatSelector;
    private JTextField messageField;
    private Map<String, List<String>> messageCache;

    public User(String name, ChatMediator mediator) {
        this.name = name;
        this.mediator = mediator;
        this.joinedConversations = new ArrayList<>();
        this.messageCache = new HashMap<>();

        // Create a new chat window for each user
        JFrame frame = new JFrame(name + "'s Chat");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        chatArea = new JTextArea();
        chatArea.setEditable(false);

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.add(new JScrollPane(chatArea), BorderLayout.CENTER);

        chatSelector = new JComboBox<>();

        chatSelector.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedConversation = (String) chatSelector.getSelectedItem();
                if (selectedConversation != null) {
                    updateConversation(selectedConversation);
                }
            }
        });

        JPanel selectorPanel = new JPanel();
        selectorPanel.add(new JLabel("Select Chat:"));
        selectorPanel.add(chatSelector);

        panel.add(selectorPanel, BorderLayout.NORTH);

        messageField = new JTextField();
        JButton sendButton = new JButton("Send");

        sendButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String message = messageField.getText();
                String selectedConversation = (String) chatSelector.getSelectedItem();
                if (selectedConversation != null) {
                    mediator.sendMessage(name + ": " + message, User.this, selectedConversation);
                    messageField.setText("");
                }
            }
        });

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new BorderLayout());
        inputPanel.add(messageField, BorderLayout.CENTER);
        inputPanel.add(sendButton, BorderLayout.EAST);

        panel.add(inputPanel, BorderLayout.SOUTH);

        frame.getContentPane().add(panel);
        frame.setVisible(true);
    }

    public void receiveMessage(String message, String conversationId) {
        List<String> messages = messageCache.computeIfAbsent(conversationId, k -> new ArrayList<>());
        messages.add(message);

        // Update the conversation only if the message is for the selected conversation
        if (conversationId.equals(chatSelector.getSelectedItem())) {
            updateConversation(conversationId);
        }
    }

    public void joinConversation(String conversationId) {
        if (!joinedConversations.contains(conversationId)) {
            joinedConversations.add(conversationId);
            chatSelector.addItem(conversationId);
        }
        updateConversation(conversationId);
    }

    private void updateConversation(String conversationId) {
        chatArea.setText(""); // Limpiar el área de chat
        List<String> messages = messageCache.get(conversationId);
        if (messages != null) {
            for (String message : messages) {
                chatArea.append(message + "\n");
            }
        }
    }
}