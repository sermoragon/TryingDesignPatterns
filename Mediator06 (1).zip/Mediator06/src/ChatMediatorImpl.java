import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChatMediatorImpl implements ChatMediator {
    private Map<String, List<User>> conversations;

    public ChatMediatorImpl() {
        this.conversations = new HashMap<>();
    }

    public Map<String, List<User>> getConversations() {
        return conversations;
    }

    public void addUserToConversation(String conversationId, User user) {
        this.conversations.computeIfAbsent(conversationId, k -> new ArrayList<>()).add(user);
        user.joinConversation(conversationId);
    }

    @Override
    public void sendMessage(String message, User sender, String conversationId) {
        for (User user : conversations.get(conversationId)) {
            user.receiveMessage(message, conversationId);
        }
    }
}
