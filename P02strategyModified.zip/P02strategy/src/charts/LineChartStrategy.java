package charts;

import charts.ChartStrategy;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

public class LineChartStrategy implements ChartStrategy {
    @Override
    public JFreeChart createChart(DefaultCategoryDataset dataset, String chartTitle, String xLabel, String yLabel) {
        JFreeChart chart = ChartFactory.createLineChart(
                chartTitle,
                xLabel,
                yLabel,
                dataset,
                PlotOrientation.VERTICAL,
                true,
                true,
                false
        );
        return chart;
    }
}
