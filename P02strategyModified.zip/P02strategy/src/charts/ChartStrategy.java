package charts;

import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;

public interface ChartStrategy {
    JFreeChart createChart(DefaultCategoryDataset dataset, String chartTitle, String xLabel, String yLabel);
}
