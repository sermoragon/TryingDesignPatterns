package charts;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

public class BarChartStrategy implements ChartStrategy {
    @Override
    public JFreeChart createChart(DefaultCategoryDataset dataset, String chartTitle, String xLabel, String yLabel) {
        JFreeChart chart = ChartFactory.createBarChart(
                chartTitle,
                xLabel,
                yLabel,
                dataset,
                PlotOrientation.VERTICAL,
                true,
                true,
                false
        );
        return chart;
    }
}
