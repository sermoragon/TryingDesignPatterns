import gui.ChartApp;
import parsers.CsvDownloaderAndParser;
import parsers.FormatedDataContainer;

import javax.swing.*;

public class MainApp {

    public static void main(String[] args) {
        // String csvUrl = "https://www.santacruzdetenerife.es/opendata/dataset/49b30b9c-c7b6-41ad-baba-7f60567f5f31/resource/4cb7d07c-abc6-42dd-800c-df3278f58819/download/aytosc_deudapublica_5a-1.csv";
        // String csvUrl = "https://drive.google.com/uc?export=download&id=1hHTCUL8RkbqGGPzEKX21vNllIkhhkBNI";
        // String csvUrl = "https://docs.google.com/spreadsheets/d/e/2PACX-1vTBEJae_Rvkd0Ufl5pkrOkl9rwDxe3KvdTbC2v9DIq73xlajK9-AX5_iytV5-QKw08nWiIGzmMNIV5s/pub?output=csv"
        FormatedDataContainer container = CsvDownloaderAndParser.downloadAndParseCsv(args[0]);

        SwingUtilities.invokeLater(() -> {
            ChartApp app = new ChartApp("Aplicación de Gráficos", container);
            app.setVisible(true);
        });
    }
}
