package gui;
import parsers.FormatedDataContainer;

import charts.BarChartStrategy;
import charts.ChartStrategy;
import charts.LineChartStrategy;
import org.jfree.data.category.DefaultCategoryDataset;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.ChartPanel;


public class ChartApp extends JFrame implements ActionListener {

    private JComboBox<String> chartTypeComboBox;
    private JButton showButton;
    private ChartStrategy chartStrategy; // Estrategia de gráfico
    private DefaultCategoryDataset dataset; // Conjunto de datos común
    private JFreeChart chart;
    private FormatedDataContainer container;

    public ChartApp(String title, FormatedDataContainer container) {
        super(title);
        this.container = container;
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 150);

        // Crear el conjunto de datos para el gráfico (puedes personalizar estos datos)
        dataset = new DefaultCategoryDataset();
        // Se agregan datos de las columnas al dataset para representarlos en las graficas
        for (int i = 0; i < container.getDatosColumna1().size(); i++) {
            dataset.addValue(Double.parseDouble(container.getDatosColumna2().get(i)), container.getNombreColumna2(), container.getDatosColumna1().get(i));
        }

        chartTypeComboBox = new JComboBox<>(new String[]{"Gráfico de Líneas", "Diagrama de Barras"});
        showButton = new JButton("Mostrar");
        showButton.addActionListener(this);

        JPanel controlPanel = new JPanel();
        controlPanel.add(new JLabel("Selecciona el tipo de gráfico:"));
        controlPanel.add(chartTypeComboBox);
        controlPanel.add(showButton);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(controlPanel, BorderLayout.NORTH);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == showButton) {
            String selectedChartType = (String) chartTypeComboBox.getSelectedItem();

            if (selectedChartType.equals("Gráfico de Líneas")) {
                chartStrategy = new LineChartStrategy();
            } else if (selectedChartType.equals("Diagrama de Barras")) {
                chartStrategy = new BarChartStrategy();
            }

            // Utiliza la estrategia de gráfico para crear el gráfico
            chart = chartStrategy.createChart(dataset, selectedChartType, container.getNombreColumna1(), container.getNombreColumna2());

            // Muestra el gráfico en una ventana
            ChartPanel chartPanel = new ChartPanel(chart);
            chartPanel.setPreferredSize(new Dimension(800, 600));

            JFrame frame = new JFrame(selectedChartType);
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame.getContentPane().add(chartPanel);
            frame.pack();
            frame.setVisible(true);
        }
    }
}
