package parsers;

import java.util.List;

public class FormatedDataContainer {
    private String nombreColumna1;
    private String nombreColumna2;
    private List<String> datosColumna1;
    private List<String> datosColumna2;

    public FormatedDataContainer(String nombreColumna1, String nombreColumna2, List<String> datosColumna1, List<String> datosColumna2) {
        this.nombreColumna1 = nombreColumna1;
        this.nombreColumna2 = nombreColumna2;
        this.datosColumna1 = datosColumna1;
        this.datosColumna2 = datosColumna2;
    }

    // Agrega getters y setters según sea necesario

    public String getNombreColumna1() {
        return nombreColumna1;
    }

    public void setNombreColumna1(String nombreColumna1) {
        this.nombreColumna1 = nombreColumna1;
    }

    public String getNombreColumna2() {
        return nombreColumna2;
    }

    public void setNombreColumna2(String nombreColumna2) {
        this.nombreColumna2 = nombreColumna2;
    }

    public List<String> getDatosColumna1() {
        return datosColumna1;
    }

    public void setDatosColumna1(List<String> datosColumna1) {
        this.datosColumna1 = datosColumna1;
    }

    public List<String> getDatosColumna2() {
        return datosColumna2;
    }

    public void setDatosColumna2(List<String> datosColumna2) {
        this.datosColumna2 = datosColumna2;
    }
}
