package parsers;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import parsers.CsvParserStrategy;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Format2CsvParser implements CsvParserStrategy {
    @Override
    public FormatedDataContainer parseCsv(String csvUrl) {
        String nombreColumna1 = null;
        String nombreColumna2 = null;
        List<String> datosColumna1 = new ArrayList<>();
        List<String> datosColumna2 = new ArrayList<>();

        try {
            // Crea una conexión a la URL y abre un flujo de entrada
            URL url = new URL(csvUrl);
            BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));

            // Crea un analizador CSV utilizando Apache Commons CSV
            CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT);

            // Obtiene la primera fila que contiene los nombres de las columnas
            CSVRecord headerRecord = csvParser.iterator().next();
            if (headerRecord.size() >= 1) {
                // Asigna el nombre de la primera columna a nombreColumna1
                nombreColumna1 = headerRecord.get(0);
            }

            // Verifica que haya al menos tres columnas en el CSV
            if (headerRecord.size() >= 3) {
                // Asigna el nombre de la tercera columna a nombreColumna2
                nombreColumna2 = headerRecord.get(2);
            } else {
                // Si no hay al menos tres columnas, muestra un mensaje de error
                System.err.println("El CSV no tiene al menos tres columnas.");
                return null; // O maneja el error de acuerdo a tus necesidades
            }

            // Itera a través del resto de filas del archivo CSV
            for (CSVRecord csvRecord : csvParser) {
                // Agrega los datos de la primera columna al arreglo "datosColumna1"
                datosColumna1.add(csvRecord.get(0));

                // Agrega los datos de la tercera columna al arreglo "datosColumna2"
                datosColumna2.add(csvRecord.get(2));
            }

            // Cierra el analizador y el flujo de entrada
            csvParser.close();
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Crea un objeto parsers.FormatedDataContainer con los datos obtenidos
        return new FormatedDataContainer(nombreColumna1, nombreColumna2, datosColumna1, datosColumna2);
    }

}