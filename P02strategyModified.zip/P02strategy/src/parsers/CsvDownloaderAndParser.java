package parsers;

public class CsvDownloaderAndParser {
    public static FormatedDataContainer downloadAndParseCsv(String csvUrl) {
        CsvParserStrategy parserStrategy;

        // Determina qué implementación utilizar según la URL
        if (csvUrl.equals("https://www.santacruzdetenerife.es/opendata/dataset/49b30b9c-c7b6-41ad-baba-7f60567f5f31/resource/4cb7d07c-abc6-42dd-800c-df3278f58819/download/aytosc_deudapublica_5a-1.csv")) {
            parserStrategy = new Format1CsvParser();
        } else if (csvUrl.equals("https://drive.google.com/uc?export=download&id=1hHTCUL8RkbqGGPzEKX21vNllIkhhkBNI")) {
            parserStrategy = new Format2CsvParser();
        } else if (csvUrl.equals("https://docs.google.com/spreadsheets/d/e/2PACX-1vTBEJae_Rvkd0Ufl5pkrOkl9rwDxe3KvdTbC2v9DIq73xlajK9-AX5_iytV5-QKw08nWiIGzmMNIV5s/pub?output=csv")) {
            parserStrategy = new Format3CsvParser();
        } else {
            throw new IllegalArgumentException("URL no compatible");
        }

        return parserStrategy.parseCsv(csvUrl);
    }
}
