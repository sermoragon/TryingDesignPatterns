package parsers;

public interface CsvParserStrategy {
    FormatedDataContainer parseCsv(String csvUrl);
}
