import common.*;


public class TrafficLightApp {
    public static void main(String[] args) {
        TrafficLightContext trafficLight = new TrafficLightContext();
        trafficLight.run();
    }
}
