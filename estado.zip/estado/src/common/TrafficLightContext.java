package common;

import states.*;

import javax.swing.*;

// Context that manages the current state of the traffic light
public class TrafficLightContext {
    private TrafficLightState state;

    public TrafficLightContext() {
        state = new RedState();
    }

    public void changeState(TrafficLightState newState) {
        state = newState;
    }

    public void run() {
        JFrame frame = new JFrame("Traffic Light");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(131, 380);

        JLabel label = new JLabel();
        frame.add(label);

        frame.setVisible(true);

        while (true) {
            ImageIcon currentImage = state.displayColor();
            label.setIcon(currentImage);

            state.lightTimer();

            if (state instanceof RedState) {
                changeState(new YellowState());
            } else if (state instanceof YellowState) {
                changeState(new GreenState());
            } else if (state instanceof GreenState) {
                changeState(new OnOffState());

                // Crea un temporizador para actualizar la imagen cada 0.5 segundos
                Timer imageUpdateTimer = new Timer(500, e -> {
                    ImageIcon changeImage = state.displayColor();
                    label.setIcon(changeImage);
                });

                imageUpdateTimer.start(); // Inicia el temporizador de actualización de la imagen
            } else if (state instanceof OnOffState) {
                changeState(new RedState());
            }
        }
    }
}
