package common;

import javax.swing.*;

// Interface for the states of the traffic light
public interface TrafficLightState {
    ImageIcon displayColor();

    void lightTimer();
}
