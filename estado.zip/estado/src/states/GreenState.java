package states;

import common.SoundUtil;
import common.TrafficLightState;

import javax.sound.sampled.Clip;
import javax.swing.*;
import java.util.concurrent.TimeUnit;

// Implementation of the Green state
public class GreenState implements TrafficLightState {
    private ImageIcon greenImage;
    private Clip greenSound;

    public GreenState() {
        greenImage = new ImageIcon("./images/green.png");
        greenSound = SoundUtil.loadSound("green.wav");
    }

    @Override
    public ImageIcon displayColor() {
        return greenImage;
    }

    @Override
    public void lightTimer() {
        try {
            if (greenSound != null) {
                greenSound.start();
            }
            TimeUnit.SECONDS.sleep(7);
            if (greenSound != null && greenSound.isRunning()) {
                greenSound.stop();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
