package states;

import common.SoundUtil;
import common.TrafficLightState;

import javax.sound.sampled.Clip;
import javax.swing.*;
import java.util.concurrent.TimeUnit;

public class OnOffState implements TrafficLightState {
    private ImageIcon offImage;
    private ImageIcon greenImage;
    private Clip offSound;
    private Timer timer;

    private boolean isOffImage = true; // Variable para alternar entre imágenes

    public OnOffState() {
        offImage = new ImageIcon("./images/off.png");
        greenImage = new ImageIcon("./images/green.png");
        offSound = SoundUtil.loadSound("off.wav"); // Carga el sonido correspondiente, asegúrate de tener el archivo "off.wav".

        // Crea un temporizador que cambia la imagen cada 0.5 segundos
        timer = new Timer(500, e -> {
            isOffImage = !isOffImage;
        });
    }


    @Override
    public ImageIcon displayColor() {
        if (isOffImage) {
            return offImage;
        } else {
            return greenImage;
        }
    }

    @Override
    public void lightTimer() {
        try {
            if (offSound != null) {
                offSound.start();
            }
            timer.start(); // Inicia el temporizador
            TimeUnit.SECONDS.sleep(3); // Tiempo total en estado OnOffState
            timer.stop(); // Detiene el temporizador
            if (offSound != null && offSound.isRunning()) {
                offSound.stop();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
