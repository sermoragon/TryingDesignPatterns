package states;

import common.SoundUtil;
import common.TrafficLightState;

import javax.sound.sampled.Clip;
import javax.swing.*;
import java.util.concurrent.TimeUnit;

// Implementation of the Yellow state
public class YellowState implements TrafficLightState {
    private ImageIcon yellowImage;
    private Clip yellowSound;

    public YellowState() {
        yellowImage = new ImageIcon("./images/yellow.png");
        yellowSound = SoundUtil.loadSound("yellow.wav");
    }

    @Override
    public ImageIcon displayColor() {
        return yellowImage;
    }

    @Override
    public void lightTimer() {
        try {
            if (yellowSound != null) {
                yellowSound.start();
            }
            TimeUnit.SECONDS.sleep(3);
            if (yellowSound != null && yellowSound.isRunning()) {
                yellowSound.stop();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
