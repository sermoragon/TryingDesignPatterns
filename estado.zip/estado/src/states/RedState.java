package states;

import common.SoundUtil;
import common.TrafficLightState;

import javax.sound.sampled.Clip;
import javax.swing.*;
import java.util.concurrent.TimeUnit;

// Implementation of the Red state
public class RedState implements TrafficLightState {
    private ImageIcon redImage;
    private Clip redSound;

    public RedState() {
        redImage = new ImageIcon("./images/red.png");
        redSound = SoundUtil.loadSound("red.wav");
    }

    @Override
    public ImageIcon displayColor() {
        return redImage;
    }

    @Override
    public void lightTimer() {
        try {
            if (redSound != null) {
                redSound.start();
            }
            TimeUnit.SECONDS.sleep(10);
            if (redSound != null && redSound.isRunning()) {
                redSound.stop();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
