#!/bin/bash

# Crear las carpetas principales
mkdir -p factory_methods_java/classes
mkdir -p factory_methods_java/factories
mkdir -p factory_methods_java/gui
mkdir -p factory_methods_java/interfaces

echo "Directorios creados con éxito!"

