import mergesort.MergeSortAlgorithm;
import mergesort.MergeSortProblem;
import mergesort.MergeSortSolution;
import matrixsum.MatrixSum;
import matrixsum.MatrixSumProblem;
import matrixsum.MatrixSumSolution;


public class Main {

    public static void main(String[] args) {
        // Prueba de Merge Sort
        int[] arrayToSort = {12, 11, 13, 5, 6, 7, 9};
        MergeSortProblem mergeSortProblem = new MergeSortProblem(arrayToSort);
        MergeSortAlgorithm mergeSortAlgorithm = new MergeSortAlgorithm();
        MergeSortSolution sortedArraySolution = (MergeSortSolution) mergeSortAlgorithm.solve(mergeSortProblem);
        int[] sortedArray = sortedArraySolution.getSortedArray();

        System.out.println("Array ordenado usando Merge Sort:");
        for (int num : sortedArray) {
            System.out.print(num + " ");
        }
        System.out.println();






        // Prueba de Matrix Sum
        int[][] matrix = {
                {1, 2, 3, 4},
                {4, 5, 6, 5},
                {4, 5, 6, 5},
                {7, 8, 9, 6}
        };

        MatrixSumProblem matrixSumProblem = new MatrixSumProblem(matrix);
        MatrixSum matrixSumAlgorithm = new MatrixSum();
        MatrixSumSolution matrixSumSolution = (MatrixSumSolution) matrixSumAlgorithm.solve(matrixSumProblem);
        int sum = matrixSumSolution.getSum();

        System.out.println("La suma de todos los elementos de la matriz es: " + sum);
    }
}
