package matrixsum;

import common.Problem;

public class MatrixSumProblem implements Problem {
    private int[][] matrix;

    public MatrixSumProblem(int[][] matrix) {
        this.matrix = matrix;
    }

    public int[][] getMatrix() {
        return matrix;
    }

    public int getMatrixSize() {
        return matrix.length;
    }
}
