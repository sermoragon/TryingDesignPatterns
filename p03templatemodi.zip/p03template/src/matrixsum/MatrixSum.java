package matrixsum;

import common.Problem;
import common.Solution;
import common.DivConqTemplate;

public class MatrixSum extends DivConqTemplate {

    @Override
    protected boolean isSimple(Problem p) {
        MatrixSumProblem problem = (MatrixSumProblem) p;
        return problem.getMatrixSize() == 1;
    }

    @Override
    protected Solution simplySolve
            (Problem p) {
        MatrixSumProblem problem = (MatrixSumProblem) p;
        return new MatrixSumSolution(problem.getMatrix()[0][0]);
    }

    @Override
    protected Problem[] decompose(Problem p) {
        MatrixSumProblem problem = (MatrixSumProblem) p;
        int n = problem.getMatrixSize();
        int[][] matrix = problem.getMatrix();

        int halfSize = n / 2;
        int[][] subMatrix1 = new int[halfSize][halfSize];
        int[][] subMatrix2 = new int[halfSize][halfSize];
        int[][] subMatrix3 = new int[halfSize][halfSize];
        int[][] subMatrix4 = new int[halfSize][halfSize];

        for (int i = 0; i < halfSize; i++) {
            for (int j = 0; j < halfSize; j++) {
                subMatrix1[i][j] = matrix[i][j];
                subMatrix2[i][j] = matrix[i][j + halfSize];
                subMatrix3[i][j] = matrix[i + halfSize][j];
                subMatrix4[i][j] = matrix[i + halfSize][j + halfSize];
            }
        }

        return new Problem[] {
                new MatrixSumProblem(subMatrix1),
                new MatrixSumProblem(subMatrix2),
                new MatrixSumProblem(subMatrix3),
                new MatrixSumProblem(subMatrix4)
        };
    }

    @Override
    protected Solution combine(Problem p, Solution[] subSolutions) {
        int sum = 0;
        for (Solution subSolution : subSolutions) {
            MatrixSumSolution subMatrixSum = (MatrixSumSolution) subSolution;
            sum += subMatrixSum.getSum();
        }
        return new MatrixSumSolution(sum);
    }
}
