package matrixsum;

import common.Solution;

public class MatrixSumSolution implements Solution {
    private int sum;

    public MatrixSumSolution(int sum) {
        this.sum = sum;
    }

    public int getSum() {
        return sum;
    }
}
