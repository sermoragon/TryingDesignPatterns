package common;

public interface Problem {
}
