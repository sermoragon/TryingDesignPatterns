package common;

public interface Solution {
    //Object solution();
}
