package mergesort;

import common.Solution;

public class MergeSortSolution implements Solution {
    private int[] sortedArray;

    public MergeSortSolution(int[] sortedArray) {
        this.sortedArray = sortedArray;
    }

    public int[] getSortedArray() {
        return sortedArray;
    }
}
