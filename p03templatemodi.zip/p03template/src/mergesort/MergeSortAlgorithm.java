package mergesort;

import common.Problem;
import common.Solution;
import common.DivConqTemplate;

import java.util.Arrays;
public class MergeSortAlgorithm extends DivConqTemplate {

    @Override
    protected boolean isSimple(Problem p) {
        MergeSortProblem problem = (MergeSortProblem) p;
        return problem.getArray().length <= 1;
    }

    @Override
    protected Solution simplySolve(Problem p) {
        MergeSortProblem problem = (MergeSortProblem) p;
        return new MergeSortSolution(mergeSort(problem.getArray()));
    }

    @Override
    protected Problem[] decompose(Problem p) {
        MergeSortProblem problem = (MergeSortProblem) p;
        int[] array = problem.getArray();
        int mid = array.length / 2;
        int[] leftHalf = Arrays.copyOfRange(array, 0, mid);
        int[] rightHalf = Arrays.copyOfRange(array, mid, array.length);
        return new Problem[] {
                new MergeSortProblem(leftHalf),
                new MergeSortProblem(rightHalf)
        };
    }

    @Override
    protected Solution combine(Problem p, Solution[] ss) {
        MergeSortSolution leftSolution = (MergeSortSolution) ss[0];
        MergeSortSolution rightSolution = (MergeSortSolution) ss[1];

        int[] mergedArray = merge(leftSolution.getSortedArray(), rightSolution.getSortedArray());
        return new MergeSortSolution(mergedArray);
    }

    private int[] merge(int[] left, int[] right) {
        int[] merged = new int[left.length + right.length];
        int i = 0, j = 0, k = 0;

        while (i < left.length && j < right.length) {
            if (left[i] < right[j]) {
                merged[k++] = left[i++];
            } else {
                merged[k++] = right[j++];
            }
        }

        while (i < left.length) {
            merged[k++] = left[i++];
        }

        while (j < right.length) {
            merged[k++] = right[j++];
        }

        return merged;
    }

    private int[] mergeSort(int[] array) {
        if (array.length <= 1) {
            return array;
        }

        int mid = array.length / 2;
        int[] left = Arrays.copyOfRange(array, 0, mid);
        int[] right = Arrays.copyOfRange(array, mid, array.length);

        left = mergeSort(left);
        right = mergeSort(right);

        return merge(left, right);
    }
}

