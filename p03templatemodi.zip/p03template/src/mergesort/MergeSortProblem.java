package mergesort;

import common.Problem;

public class MergeSortProblem implements Problem {
    private int[] array;

    public MergeSortProblem(int[] array) {
        this.array = array;
    }

    public int[] getArray() {
        return array;
    }
}
