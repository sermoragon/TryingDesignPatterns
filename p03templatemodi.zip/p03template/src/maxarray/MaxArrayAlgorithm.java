package maxarray;

import common.DivConqTemplate;
import common.Problem;
import common.Solution;
import mergesort.MergeSortProblem;
import mergesort.MergeSortSolution;


import java.util.Arrays;

public class MaxArrayAlgorithm extends DivConqTemplate {

    @Override
    protected boolean isSimple(Problem p) {
        MaxProblem problem = (MaxProblem) p;
        return problem.getArray().length <= 1;
    }

    @Override
    protected Solution simplySolve(Problem p) {
        MaxProblem problem = (MaxProblem) p;
        return new MaxSolution(maxCalculation(problem.getArray()));
    }

    @Override
    protected Problem[] decompose(Problem p) {
        MaxProblem problem = (MaxProblem) p;
        int[] array = problem.getArray();
        int firstThird = array.length / 3;
        int secondThird = (array.length * 2)/ 3;
        int[] leftPart = Arrays.copyOfRange(array, 0, firstThird);
        int[] middlePart = Arrays.copyOfRange(array, firstThird, secondThird);
        int[] rightPart = Arrays.copyOfRange(array, secondThird, array.length);
        return new Problem[] {
                new MaxProblem(leftPart),
                new MaxProblem(middlePart),
                new MaxProblem(rightPart),
        };
    }

    @Override
    protected Solution combine(Problem p, Solution[] ss) {
        MaxSolution leftSolution = (MaxSolution) ss[0];
        MaxSolution middleSolution = (MaxSolution) ss[1];
        MaxSolution rightSolution = (MaxSolution) ss[3];

        int[] mergedArray = merge(leftSolution.getSortedArray(), rightSolution.getSortedArray());
        return new MergeSortSolution(mergedArray);
    }

    private int[] maxCalculation(int[] array) {
        if (array.length <= 1) {
            return array;
        }

        int firstThird = array.length / 3;
        int secondThird = (array.length * 2)/ 3;
        int[] left = Arrays.copyOfRange(array, 0, firstThird);
        int[] middle = Arrays.copyOfRange(array, firstThird, secondThird);
        int[] right = Arrays.copyOfRange(array, secondThird, array.length);

        left = maxCalculation(left);
        middle = maxCalculation(middle);
        right = maxCalculation(right);

        return merge(left, right);
    }
}
