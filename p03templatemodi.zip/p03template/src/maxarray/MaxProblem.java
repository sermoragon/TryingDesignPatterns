package maxarray;

import common.Problem;

public class MaxProblem implements Problem {
    private int[] array;

    public MaxProblem(int[] array) {
        this.array = array;
    }

    public int[] getArray() {
        return array;
    }
}
