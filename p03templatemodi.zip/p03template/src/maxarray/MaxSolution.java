package maxarray;

import common.Solution;

public class MaxSolution implements Solution {
    private int[] array;

    public MaxSolution(int[] array) {
        this.array = array;
    }

    public int[] getArray() {
        return array;
    }
}
